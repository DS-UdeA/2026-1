class BPlusTreeNode:
    """Base node class for B+tree."""
    def __init__(self, order, is_leaf=False):
        self.order = order
        self.is_leaf = is_leaf
        self.keys = []
        self.children = [] if not is_leaf else []
        self.parent = None

    def __repr__(self):
        return f"{'Leaf' if self.is_leaf else 'Internal'}({self.keys})"


class BPlusTreeLeaf(BPlusTreeNode):
    """Leaf node stores (key, value) pairs and links to next/prev leaf."""
    def __init__(self, order):
        super().__init__(order, is_leaf=True)
        self.values = []
        self.next_leaf = None
        self.prev_leaf = None


class BPlusTreeInternal(BPlusTreeNode):
    """Internal node stores keys and child pointers."""
    def __init__(self, order):
        super().__init__(order, is_leaf=False)
        self.children = []


class BPlusTree:
    """B+tree implementation with insert, search, delete, and range query."""

    def __init__(self, order=3):
        if order < 2:
            raise ValueError("Order must be >= 2")
        self.order = order
        self.root = BPlusTreeLeaf(order)

    def search(self, key):
        """Search for key and return value, or None if not found."""
        leaf = self._find_leaf(key)
        if key in leaf.keys:
            idx = leaf.keys.index(key)
            return leaf.values[idx]
        return None

    def range_query(self, start_key, end_key):
        """Return all (key, value) pairs where start_key <= key <= end_key."""
        leaf = self._find_leaf(start_key)
        results = []

        while leaf:
            for i, key in enumerate(leaf.keys):
                if start_key <= key <= end_key:
                    results.append((key, leaf.values[i]))
                elif key > end_key:
                    return results
            leaf = leaf.next_leaf

        return results

    def insert(self, key, value):
        """Insert (key, value) pair. Discard if key exists."""
        if self.search(key) is not None:
            return

        leaf = self._find_leaf(key)
        self._insert_into_leaf(leaf, key, value)

        if len(leaf.keys) > self.order - 1:
            self._split_leaf(leaf)

    def delete(self, key):
        """Delete key-value pair. Raises KeyError if not found."""
        leaf = self._find_leaf(key)

        if key not in leaf.keys:
            raise KeyError(f"Key {key} not found")

        idx = leaf.keys.index(key)
        leaf.keys.pop(idx)
        leaf.values.pop(idx)

        if leaf is not self.root and len(leaf.keys) < (self.order + 1) // 2:
            self._rebalance_leaf(leaf)

    def _find_leaf(self, key):
        """Find leaf node where key should be inserted/found."""
        node = self.root

        while not node.is_leaf:
            idx = 0
            while idx < len(node.keys) and key >= node.keys[idx]:
                idx += 1
            node = node.children[idx]

        return node

    def _insert_into_leaf(self, leaf, key, value):
        """Insert key-value into leaf in sorted order."""
        idx = 0
        while idx < len(leaf.keys) and key > leaf.keys[idx]:
            idx += 1
        leaf.keys.insert(idx, key)
        leaf.values.insert(idx, value)

    def _split_leaf(self, leaf):
        """Split full leaf and propagate up if needed."""
        mid = len(leaf.keys) // 2

        new_leaf = BPlusTreeLeaf(self.order)
        new_leaf.keys = leaf.keys[mid:]
        new_leaf.values = leaf.values[mid:]
        leaf.keys = leaf.keys[:mid]
        leaf.values = leaf.values[:mid]

        new_leaf.next_leaf = leaf.next_leaf
        new_leaf.prev_leaf = leaf
        if leaf.next_leaf:
            leaf.next_leaf.prev_leaf = new_leaf
        leaf.next_leaf = new_leaf

        self._insert_into_parent(leaf, new_leaf.keys[0], new_leaf)

    def _split_internal(self, internal):
        """Split full internal node."""
        mid = len(internal.keys) // 2
        new_internal = BPlusTreeInternal(self.order)

        new_internal.keys = internal.keys[mid + 1:]
        new_internal.children = internal.children[mid + 1:]

        for child in new_internal.children:
            child.parent = new_internal

        promote_key = internal.keys[mid]
        internal.keys = internal.keys[:mid]
        internal.children = internal.children[:mid + 1]

        self._insert_into_parent(internal, promote_key, new_internal)

    def _insert_into_parent(self, left, key, right):
        """Insert promoted key into parent or create new root."""
        if left.parent is None:
            new_root = BPlusTreeInternal(self.order)
            new_root.keys = [key]
            new_root.children = [left, right]
            left.parent = new_root
            right.parent = new_root
            self.root = new_root
            return

        parent = left.parent
        idx = parent.children.index(left)
        parent.keys.insert(idx, key)
        parent.children.insert(idx + 1, right)
        right.parent = parent

        if len(parent.keys) > self.order - 1:
            self._split_internal(parent)

    def _rebalance_leaf(self, leaf):
        """Rebalance leaf by borrowing or merging."""
        parent = leaf.parent
        idx = parent.children.index(leaf)

        # Try borrow from right sibling
        if idx < len(parent.children) - 1:
            right_sibling = parent.children[idx + 1]
            if len(right_sibling.keys) > (self.order + 1) // 2:
                leaf.keys.append(right_sibling.keys.pop(0))
                leaf.values.append(right_sibling.values.pop(0))
                parent.keys[idx] = right_sibling.keys[0]
                return

        # Try borrow from left sibling
        if idx > 0:
            left_sibling = parent.children[idx - 1]
            if len(left_sibling.keys) > (self.order + 1) // 2:
                leaf.keys.insert(0, left_sibling.keys.pop())
                leaf.values.insert(0, left_sibling.values.pop())
                parent.keys[idx - 1] = leaf.keys[0]
                return

        # Merge with sibling
        if idx < len(parent.children) - 1:
            self._merge_leaves(leaf, parent.children[idx + 1], idx)
        else:
            self._merge_leaves(parent.children[idx - 1], leaf, idx - 1)

    def _merge_leaves(self, left, right, key_idx):
        """Merge right leaf into left leaf."""
        left.keys.extend(right.keys)
        left.values.extend(right.values)
        left.next_leaf = right.next_leaf
        if right.next_leaf:
            right.next_leaf.prev_leaf = left

        parent = left.parent
        parent.keys.pop(key_idx)
        parent.children.pop(key_idx + 1)

        if parent is not self.root and len(parent.keys) < (self.order + 1) // 2:
            self._rebalance_internal(parent)
        elif parent is self.root and len(parent.keys) == 0:
            self.root = left

    def _rebalance_internal(self, internal):
        """Rebalance internal node by borrowing or merging."""
        parent = internal.parent
        idx = parent.children.index(internal)

        # Try borrow from right sibling
        if idx < len(parent.children) - 1:
            right_sibling = parent.children[idx + 1]
            if len(right_sibling.keys) > (self.order + 1) // 2:
                internal.keys.append(parent.keys[idx])
                parent.keys[idx] = right_sibling.keys.pop(0)
                internal.children.append(right_sibling.children.pop(0))
                internal.children[-1].parent = internal
                return

        # Try borrow from left sibling
        if idx > 0:
            left_sibling = parent.children[idx - 1]
            if len(left_sibling.keys) > (self.order + 1) // 2:
                internal.keys.insert(0, parent.keys[idx - 1])
                parent.keys[idx - 1] = left_sibling.keys.pop()
                internal.children.insert(0, left_sibling.children.pop())
                internal.children[0].parent = internal
                return

        # Merge with sibling
        if idx < len(parent.children) - 1:
            self._merge_internal(internal, parent.children[idx + 1], idx)
        else:
            self._merge_internal(parent.children[idx - 1], internal, idx - 1)

    def _merge_internal(self, left, right, key_idx):
        """Merge right internal node into left."""
        left.keys.append(left.parent.keys.pop(key_idx))
        left.keys.extend(right.keys)
        left.children.extend(right.children)

        for child in right.children:
            child.parent = left

        parent = left.parent
        parent.children.pop(key_idx + 1)

        if parent is not self.root and len(parent.keys) < (self.order + 1) // 2:
            self._rebalance_internal(parent)
        elif parent is self.root and len(parent.keys) == 0:
            self.root = left

    def print_tree(self):
        """Print tree structure level by level."""
        if not self.root:
            print("Empty tree")
            return

        from collections import deque
        queue = deque([(self.root, 0)])
        current_level = 0

        while queue:
            node, level = queue.popleft()

            if level > current_level:
                print()
                current_level = level

            print(f"{node}", end="  ")

            if not node.is_leaf:
                for child in node.children:
                    queue.append((child, level + 1))

        print("\n")

    def to_sorted_list(self):
        """Return all (key, value) pairs in sorted order."""
        result = []
        leaf = self.root

        while not leaf.is_leaf and leaf.children:
            leaf = leaf.children[0]

        while leaf:
            for key, value in zip(leaf.keys, leaf.values):
                result.append((key, value))
            leaf = leaf.next_leaf

        return result


if __name__ == "__main__":
    # Example usage
    bpt = BPlusTree(order=3)

    # Insert data
    data = [(10, "A"), (20, "B"), (5, "E"), (6, "F"), (12, "G"), (
        30, "C"), (7, "H"), (17, "I")]

    for key, value in data:
        bpt.insert(key, value)

    print("Tree after insertions:")
    bpt.print_tree()

    print("Sorted data:", bpt.to_sorted_list())

    # Search
    print(f"\nSearch for 12: {bpt.search(12)}")
    print(f"Search for 100: {bpt.search(100)}")

    # Range query
    print(f"\nRange query [6, 20]: {bpt.range_query(6, 20)}")

    # Delete
    print("\nDeleting key 20...")
    bpt.delete(20)
    print("Tree after deletion:")
    bpt.print_tree()
    print("Sorted data:", bpt.to_sorted_list())
