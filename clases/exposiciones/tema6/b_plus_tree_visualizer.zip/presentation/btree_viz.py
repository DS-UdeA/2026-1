#!/usr/bin/env python3
"""B+ Tree Visualizer — neon emerald theme, step-by-step animations."""

import tkinter as tk
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from btree_plus import BPlusTree

# ── Palette ───────────────────────────────────────────────────────────────────
BG          = "#060e06"
CANVAS_BG   = "#060e06"
PANEL_BG    = "#0b160b"
NODE_FILL   = "#0c230c"
NODE_BORDER = "#00e676"
TEXT_COL    = "#00e676"
DIM_COL     = "#143814"
LABEL_COL   = "#00a050"
BTN_BG      = "#0c230c"
ENTRY_BG    = "#060e06"
ENTRY_FG    = "#00ff7f"
CURSOR_COL  = "#00ff7f"
SEL_BG      = "#0f3f0f"
LEAF_LINK   = "#003a1a"
EDGE_COL    = "#005c28"
ROOT_COL    = "#ff9900"
GRID_COL    = "#090f09"
LEAF_BAR    = "#00b050"

HL_SEARCH   = "#ffe000"   # amber   – comparing
HL_INSERT   = "#00e5ff"   # cyan    – insert path
HL_DELETE   = "#ff3d3d"   # red     – delete path
HL_FOUND    = "#d500f9"   # magenta – target found

# ── Geometry ──────────────────────────────────────────────────────────────────
NODE_H   = 40
KEY_W    = 38
KEY_PAD  = 10
MIN_W    = 58
LEVEL_H  = 100
LEAF_GAP = 24
H_MARGIN = 60
V_MARGIN = 50

# Default tree designed so each deletion case is demonstrable:
#                       [50]
#              /                  \
#         [25, 35]              [75, 85]
#         /  |  \               /  |  \
#  [10,15,20][25,30][35,45][50,55,60][75,80][85,90,95]
#
# Demo sequence (run on order=4):
#   delete 15  -> Case 1: easy delete, leaf still ≥ min keys
#   delete 30  -> Case 2: borrow from LEFT sibling [10,15,20]
#   delete 75  -> Case 3: borrow from RIGHT sibling [85,90,95]
#   delete 45  -> Case 4: merge with sibling + cascade collapses root
SAMPLE_DATA = [
    (20, "a"), (15, "b"), (25, "c"), (35, "d"), (95, "e"), (10, "f"),
    (50, "g"), (85, "h"), (30, "i"), (55, "j"), (90, "k"), (45, "l"),
    (80, "m"), (75, "n"), (60, "o"),
]


# ── Layout helpers ────────────────────────────────────────────────────────────

def node_w(node):
    return max(MIN_W, len(node.keys) * KEY_W + 2 * KEY_PAD)


def tree_height(node):
    if node.is_leaf:
        return 1
    return 1 + tree_height(node.children[0])


def get_leaves(tree):
    n = tree.root
    while not n.is_leaf:
        n = n.children[0]
    leaves = []
    while n:
        leaves.append(n)
        n = n.next_leaf
    return leaves


def dim(hex_color, factor=0.30):
    """Return darkened version of a hex color string."""
    r = int(hex_color[1:3], 16)
    g = int(hex_color[3:5], 16)
    b = int(hex_color[5:7], 16)
    return f"#{int(r*factor):02x}{int(g*factor):02x}{int(b*factor):02x}"


def compute_layout(tree, cw, ch):
    """Return {id(node): (cx, cy, w, h)} for every node in the tree."""
    pos = {}
    h   = tree_height(tree.root)
    leaves = get_leaves(tree)

    total_lw = (sum(node_w(l) for l in leaves)
                + LEAF_GAP * max(0, len(leaves) - 1))
    lx     = max(H_MARGIN, (cw - total_lw) / 2)
    leaf_y = V_MARGIN + (h - 1) * LEVEL_H + NODE_H / 2

    for leaf in leaves:
        w = node_w(leaf)
        pos[id(leaf)] = (lx + w / 2, leaf_y, w, NODE_H)
        lx += w + LEAF_GAP

    def lay(node, level):
        if node.is_leaf:
            return pos[id(node)][0]
        child_xs = [lay(c, level + 1) for c in node.children]
        cx = (child_xs[0] + child_xs[-1]) / 2
        y  = V_MARGIN + level * LEVEL_H + NODE_H / 2
        pos[id(node)] = (cx, y, node_w(node), NODE_H)
        return cx

    if not tree.root.is_leaf:
        lay(tree.root, 0)

    return pos


# ── Visualizer ────────────────────────────────────────────────────────────────

class BTreeViz:
    def __init__(self, win):
        self.win        = win
        self.tree       = BPlusTree(order=4)
        self.highlights = {}        # id(node) → color str
        self.animating  = False
        self._after_id  = None
        self._build_ui()
        for k, v in SAMPLE_DATA:
            self.tree.insert(k, v)
        self.win.after(60, self._render)

    # ── UI construction ───────────────────────────────────────────────────────

    def _build_ui(self):
        self.win.title("B⁺ Tree Visualizer")
        self.win.configure(bg=BG)
        self.win.geometry("1300x740")
        self.win.minsize(900, 560)

        # ── top bar ───────────────────────────────────────────────────────
        top = tk.Frame(self.win, bg=PANEL_BG, height=52)
        top.pack(fill=tk.X)
        top.pack_propagate(False)

        tk.Label(top, text="B⁺ TREE VISUALIZER",
                 font=("Courier", 17, "bold"),
                 bg=PANEL_BG, fg=TEXT_COL).pack(side=tk.LEFT, padx=20)

        # order spinbox
        tk.Label(top, text="Order:", font=("Courier", 10),
                 bg=PANEL_BG, fg=LABEL_COL).pack(side=tk.LEFT, padx=(24, 4))
        self.order_var = tk.StringVar(value="4")
        tk.Spinbox(top, from_=2, to=9, width=2,
                   textvariable=self.order_var,
                   font=("Courier", 12), bg=ENTRY_BG, fg=ENTRY_FG,
                   buttonbackground=BTN_BG,
                   insertbackground=CURSOR_COL,
                   selectbackground=SEL_BG,
                   relief=tk.FLAT
                   ).pack(side=tk.LEFT)

        self._btn(top, "RESET", self._reset).pack(side=tk.LEFT, padx=(10, 0))

        # speed
        tk.Label(top, text="Slow", font=("Courier", 8),
                 bg=PANEL_BG, fg=DIM_COL).pack(side=tk.RIGHT, padx=(0, 12))
        self.speed = tk.IntVar(value=550)
        tk.Scale(top, from_=1500, to=80, orient=tk.HORIZONTAL,
                 variable=self.speed, length=140,
                 bg=PANEL_BG, fg=TEXT_COL, troughcolor=DIM_COL,
                 highlightthickness=0, bd=0, showvalue=0
                 ).pack(side=tk.RIGHT)
        tk.Label(top, text="Fast", font=("Courier", 8),
                 bg=PANEL_BG, fg=DIM_COL).pack(side=tk.RIGHT, padx=(0, 4))

        # ── canvas ────────────────────────────────────────────────────────
        self.canvas = tk.Canvas(self.win, bg=CANVAS_BG, highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self.canvas.bind("<Configure>", lambda _e: self._render())

        # ── bottom bar ────────────────────────────────────────────────────
        bot = tk.Frame(self.win, bg=PANEL_BG)
        bot.pack(fill=tk.X)

        self.status = tk.StringVar(value="Ready.  (sample data loaded)")
        tk.Label(bot, textvariable=self.status,
                 font=("Courier", 11), bg=PANEL_BG, fg=TEXT_COL,
                 anchor=tk.W, width=56
                 ).pack(side=tk.LEFT, padx=16, pady=8)

        # legend
        legend = tk.Frame(bot, bg=PANEL_BG)
        legend.pack(side=tk.LEFT, padx=20)
        for lbl, col in (("SEARCH", HL_SEARCH), ("INSERT", HL_INSERT),
                         ("DELETE", HL_DELETE), ("FOUND", HL_FOUND)):
            tk.Label(legend, text="■", font=("Courier", 12),
                     bg=PANEL_BG, fg=col).pack(side=tk.LEFT)
            tk.Label(legend, text=lbl + "  ", font=("Courier", 8),
                     bg=PANEL_BG, fg=LABEL_COL).pack(side=tk.LEFT)

        # input controls
        ctrl = tk.Frame(bot, bg=PANEL_BG)
        ctrl.pack(side=tk.RIGHT, padx=16, pady=8)

        tk.Label(ctrl, text="Key:", font=("Courier", 11),
                 bg=PANEL_BG, fg=LABEL_COL).pack(side=tk.LEFT)
        self.key_e = tk.Entry(ctrl, width=6, font=("Courier", 12),
                              bg=ENTRY_BG, fg=ENTRY_FG,
                              insertbackground=CURSOR_COL,
                              selectbackground=SEL_BG, relief=tk.FLAT)
        self.key_e.pack(side=tk.LEFT, padx=(4, 14))

        tk.Label(ctrl, text="Value:", font=("Courier", 11),
                 bg=PANEL_BG, fg=LABEL_COL).pack(side=tk.LEFT)
        self.val_e = tk.Entry(ctrl, width=6, font=("Courier", 12),
                              bg=ENTRY_BG, fg=ENTRY_FG,
                              insertbackground=CURSOR_COL,
                              selectbackground=SEL_BG, relief=tk.FLAT)
        self.val_e.pack(side=tk.LEFT, padx=(4, 14))

        self._btn(ctrl, "INSERT", self._insert_action,
                  HL_INSERT).pack(side=tk.LEFT, padx=3)
        self._btn(ctrl, "DELETE", self._delete_action,
                  HL_DELETE).pack(side=tk.LEFT, padx=3)
        self._btn(ctrl, "SEARCH", self._search_action,
                  HL_SEARCH).pack(side=tk.LEFT, padx=3)

        self.key_e.bind("<Return>", lambda _e: self._insert_action())
        self.win.bind("<Escape>",   lambda _e: self._stop_anim())

    def _btn(self, parent, text, cmd, color=None, **kw):
        c = color or NODE_BORDER
        b = tk.Button(parent, text=text, command=cmd,
                      font=("Courier", 10, "bold"),
                      bg=BTN_BG, fg=c,
                      activebackground=c, activeforeground=BG,
                      relief=tk.FLAT, padx=12, pady=5,
                      cursor="hand2", **kw)
        b.bind("<Enter>", lambda _e: b.config(bg=c, fg=BG))
        b.bind("<Leave>", lambda _e: b.config(bg=BTN_BG, fg=c))
        return b

    # ── Operations ────────────────────────────────────────────────────────────

    def _get_key(self):
        try:
            return int(self.key_e.get().strip())
        except ValueError:
            self.status.set("Key must be an integer.")
            return None

    def _reset(self):
        self._stop_anim()
        try:
            order = max(2, int(self.order_var.get()))
        except ValueError:
            order = 3
        self.tree = BPlusTree(order=order)
        self.highlights = {}
        self._render()
        self.status.set(f"Tree reset. Order = {order}.")

    def _stop_anim(self):
        if self._after_id:
            self.win.after_cancel(self._after_id)
            self._after_id = None
        self.animating  = False
        self.highlights = {}

    def _search_action(self):
        if self.animating:
            return
        key = self._get_key()
        if key is None:
            return
        self._anim_search(key)

    def _insert_action(self):
        if self.animating:
            return
        key = self._get_key()
        if key is None:
            return
        val = self.val_e.get().strip() or "•"
        self._anim_insert(key, val)

    def _delete_action(self):
        if self.animating:
            return
        key = self._get_key()
        if key is None:
            return
        self._anim_delete(key)

    # ── Animation engine ──────────────────────────────────────────────────────

    def _build_path(self, key):
        """Dry-run traversal — returns list of nodes root→leaf without modifying the tree."""
        path = []
        node = self.tree.root
        while not node.is_leaf:
            path.append(node)
            idx = 0
            while idx < len(node.keys) and key >= node.keys[idx]:
                idx += 1
            node = node.children[idx]
        path.append(node)
        return path

    def _play_frames(self, frames, done_cb):
        """
        frames  : list of (highlights_dict, status_str)
        done_cb : called after last frame completes
        """
        self.animating = True

        def step(i):
            if i >= len(frames):
                done_cb()
                return
            hl, msg = frames[i]
            self.highlights = hl
            self._render()
            self.status.set(msg)
            self._after_id = self.win.after(self.speed.get(), lambda: step(i + 1))

        step(0)

    def _clear_hl(self):
        self.highlights = {}
        self._render()

    # ── Search animation ──────────────────────────────────────────────────────

    def _anim_search(self, key):
        path   = self._build_path(key)
        frames = []
        acc    = {}

        for i, node in enumerate(path):
            last = (i == len(path) - 1)
            if last:
                found = key in node.keys
                color = HL_FOUND if found else HL_DELETE
                acc   = {**acc, id(node): color}
                # highlight the specific matching key slot differently
                val_str = ""
                if found:
                    val_str = f"  →  value = '{node.values[node.keys.index(key)]}'"
                msg = (f"✓ Key {key} FOUND in leaf {node.keys}{val_str}"
                       if found else
                       f"✗ Key {key} not found in leaf {node.keys}")
            else:
                idx = sum(1 for k in node.keys if key >= k)
                acc = {**acc, id(node): HL_SEARCH}
                dir_key = (f"key ≥ {node.keys[idx-1]}" if idx > 0 and idx <= len(node.keys)
                           else "key < all" if idx == 0
                           else "key > all")
                msg = f"Internal {node.keys}:  {dir_key}  →  child[{idx}]"
            frames.append((dict(acc), msg))

        def done():
            self.animating = False
            self._after_id = self.win.after(1500, self._clear_hl)

        self._play_frames(frames, done)

    # ── Insert animation ──────────────────────────────────────────────────────

    def _anim_insert(self, key, val):
        path   = self._build_path(key)
        frames = []
        acc    = {}

        for i, node in enumerate(path):
            last = (i == len(path) - 1)
            acc  = {**acc, id(node): HL_INSERT}
            if last:
                msg = f"Leaf {node.keys}  →  inserting ({key}, '{val}')..."
            else:
                idx = sum(1 for k in node.keys if key >= k)
                msg = f"Internal {node.keys}  →  go child[{idx}]"
            frames.append((dict(acc), msg))

        def done():
            try:
                self.tree.insert(key, val)
                self.highlights = {}
                self._render()
                self.status.set(f"✓ Inserted  key={key}  value='{val}'")
            except Exception as ex:
                self.status.set(f"Insert error: {ex}")
            self.animating = False

        self._play_frames(frames, done)

    # ── Delete animation ──────────────────────────────────────────────────────

    def _anim_delete(self, key):
        path           = self._build_path(key)
        found_in_leaf  = key in path[-1].keys
        frames         = []
        acc            = {}

        for i, node in enumerate(path):
            last = (i == len(path) - 1)
            if last:
                color = HL_FOUND if found_in_leaf else HL_DELETE
                acc   = {**acc, id(node): color}
                msg   = (f"Found key {key} in leaf {node.keys}  →  deleting..."
                         if found_in_leaf else
                         f"✗ Key {key} not found in leaf {node.keys}")
            else:
                idx = sum(1 for k in node.keys if key >= k)
                acc = {**acc, id(node): HL_DELETE}
                msg = f"Internal {node.keys}  →  go child[{idx}]"
            frames.append((dict(acc), msg))

        def done():
            if found_in_leaf:
                try:
                    self.tree.delete(key)
                    self.highlights = {}
                    self._render()
                    self.status.set(f"✓ Deleted key {key}")
                except Exception as ex:
                    self.status.set(f"Delete error: {ex}")
            else:
                self.status.set(f"✗ Key {key} not found — nothing deleted.")
            self.animating = False

        self._play_frames(frames, done)

    # ── Rendering ─────────────────────────────────────────────────────────────

    def _render(self):
        c  = self.canvas
        cw = c.winfo_width()
        ch = c.winfo_height()
        c.delete("all")

        if cw < 20 or ch < 20:
            return

        # subtle dot-grid background
        for x in range(0, cw, 40):
            for y in range(0, ch, 40):
                c.create_rectangle(x, y, x+1, y+1,
                                   fill=GRID_COL, outline="")

        root = self.tree.root
        if root.is_leaf and not root.keys:
            c.create_text(cw // 2, ch // 2, text="Empty Tree",
                          font=("Courier", 22), fill=DIM_COL)
            return

        pos = compute_layout(self.tree, cw, ch)
        self._draw_edges(pos)
        self._draw_leaf_links(pos)
        self._draw_nodes(pos)

    # ── Edges (internal → children) ───────────────────────────────────────────

    def _draw_edges(self, pos):
        def recurse(node):
            if node.is_leaf:
                return
            if id(node) not in pos:
                return
            px, py, pw, ph = pos[id(node)]
            n_children = len(node.children)
            slot_w = pw / n_children
            x0 = px - pw / 2
            for i, child in enumerate(node.children):
                if id(child) in pos:
                    cx, cy, _cw, _ch = pos[id(child)]
                    hl_p = self.highlights.get(id(node))
                    hl_c = self.highlights.get(id(child))
                    color = (hl_p or hl_c or EDGE_COL)
                    width = 2 if (hl_p or hl_c) else 1
                    exit_x = x0 + (i + 0.5) * slot_w
                    self.canvas.create_line(
                        exit_x, py + ph / 2,
                        cx, cy - _ch / 2,
                        fill=color, width=width, smooth=True
                    )
                recurse(child)

        recurse(self.tree.root)

    # ── Leaf linked-list arrows ────────────────────────────────────────────────

    def _draw_leaf_links(self, pos):
        leaves = get_leaves(self.tree)
        for i in range(len(leaves) - 1):
            la, lb = leaves[i], leaves[i + 1]
            if id(la) not in pos or id(lb) not in pos:
                continue
            ax, ay, aw, _ah = pos[id(la)]
            bx, _by, bw, _bh = pos[id(lb)]
            x1 = ax + aw / 2 + 2
            x2 = bx - bw / 2 - 2
            y  = ay
            hl = id(la) in self.highlights or id(lb) in self.highlights
            color = HL_FOUND if hl else LEAF_LINK
            width = 2   if hl else 1
            self.canvas.create_line(
                x1, y, x2, y,
                fill=color, width=width,
                arrow=tk.LAST, arrowshape=(8, 10, 4)
            )

    # ── Node drawing ──────────────────────────────────────────────────────────

    def _draw_nodes(self, pos):
        def recurse(node):
            if id(node) in pos:
                self._draw_node(node, pos[id(node)])
            if not node.is_leaf:
                for child in node.children:
                    recurse(child)

        recurse(self.tree.root)

    def _draw_node(self, node, geom):
        cx, cy, w, h = geom
        x0, y0 = cx - w / 2, cy - h / 2
        x1, y1 = cx + w / 2, cy + h / 2
        hl     = self.highlights.get(id(node))
        border = hl or NODE_BORDER

        # neon glow rings when highlighted
        if hl:
            d = dim(hl, 0.25)
            self.canvas.create_rectangle(
                x0 - 6, y0 - 6, x1 + 6, y1 + 6,
                fill="", outline=d, width=1
            )
            self.canvas.create_rectangle(
                x0 - 3, y0 - 3, x1 + 3, y1 + 3,
                fill="", outline=hl, width=1
            )

        # node body
        self.canvas.create_rectangle(
            x0, y0, x1, y1,
            fill=NODE_FILL, outline=border, width=2
        )

        # key slots
        nk = max(len(node.keys), 1)
        kw = w / nk
        for i, key in enumerate(node.keys):
            if i > 0:
                sx = x0 + i * kw
                self.canvas.create_line(sx, y0, sx, y1,
                                        fill=border, width=1)
            tx = x0 + (i + 0.5) * kw
            self.canvas.create_text(
                tx, cy, text=str(key),
                font=("Courier", 11, "bold"),
                fill=(hl or TEXT_COL)
            )

        # leaf indicator bar (bottom edge)
        if node.is_leaf:
            self.canvas.create_rectangle(
                x0 + 2, y1 - 3, x1 - 2, y1,
                fill=border, outline=""
            )

        # root badge
        if node is self.tree.root:
            self.canvas.create_text(
                cx, y0 - 11, text="◆ ROOT",
                font=("Courier", 8, "bold"),
                fill=ROOT_COL
            )

        # leaf value tooltip (shown as tiny text below leaf bar)
        if node.is_leaf and hl:
            pairs = "  ".join(f"{k}:{v}" for k, v in
                              zip(node.keys, node.values))
            self.canvas.create_text(
                cx, y1 + 12, text=pairs,
                font=("Courier", 8),
                fill=hl
            )


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    win = tk.Tk()
    _app = BTreeViz(win)
    win.mainloop()
