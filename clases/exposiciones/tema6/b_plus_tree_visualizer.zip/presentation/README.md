# B+ Tree Visualizer (`btree_viz.py`)

Interactive Tkinter visualizer for the B+ Tree implemented in `btree_plus.py`. Animates search, insert, and delete step-by-step with a neon emerald theme.

## Requirements

- Python 3.x
- Tkinter
  - Linux: `sudo pacman -S tk` (Arch) or `sudo apt install python3-tk` (Debian/Ubuntu)
  - macOS / Windows: bundled with python.org installer
- `btree_plus.py` in the same directory (imported by the viz)

## Run

```bash
python3 btree_viz.py
```

Window opens at 1300×740 preloaded with `SAMPLE_DATA` (15 key/value pairs) on a tree of order 4.

## Top Bar

| Control | Effect |
|---------|--------|
| **Order** spinbox (2–9) | Sets max children per node for next reset |
| **RESET** | Wipes tree, rebuilds empty with current order |
| **Slow ◀──▶ Fast** slider | Frame delay 1500ms → 80ms |

## Bottom Bar

| Field / Button | Effect |
|----------------|--------|
| **Key** entry | Integer key (required) |
| **Value** entry | String payload (defaults to `•` if blank) |
| **INSERT** | Animate path root→leaf, then insert |
| **DELETE** | Animate path, delete if found |
| **SEARCH** | Animate path, highlight leaf result |

Status line bottom-left shows current operation step. Legend shows highlight color meanings.

## Keyboard

| Key | Action |
|-----|--------|
| `Enter` (in Key field) | Trigger INSERT |
| `Esc` | Stop running animation |

## Highlight Colors

| Color | Meaning |
|-------|---------|
| Amber | SEARCH comparison path |
| Cyan | INSERT path |
| Red | DELETE path / not found |
| Magenta | FOUND target |
| Orange `◆ ROOT` badge | Root node |
| Green bottom bar | Leaf indicator |
| Dark green arrows | Leaf linked-list pointers |

## Sample Data & Demo Sequence

Default tree (order 4) built from `SAMPLE_DATA` near top of file. Suggested deletion demo to hit each rebalance case:

| Delete | Case |
|--------|------|
| `15` | Easy delete, leaf still ≥ min |
| `75` | Borrow from RIGHT sibling |
| `45` | Merge + cascade collapse to root |

## Customization

Edit constants at top of `btree_viz.py`:

- **Palette** (`BG`, `NODE_BORDER`, `HL_*`, …) — change theme colors
- **Geometry** (`NODE_H`, `KEY_W`, `LEVEL_H`, `LEAF_GAP`, `H_MARGIN`, `V_MARGIN`) — node sizing and spacing
- **`SAMPLE_DATA`** — preload different keys
- **`BPlusTree(order=4)`** in `BTreeViz.__init__` — change default order

## Troubleshooting

- `ModuleNotFoundError: btree_plus` — run from the `presentation/` directory, or keep both files together
- `_tkinter.TclError` on Linux — install `tk` package
- Blank window / "Empty Tree" text — tree was reset; insert keys via input bar
- Animation stuck — press `Esc`
